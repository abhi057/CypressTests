class CartPage {
    openCart() {
        cy.get('#cartur').should('be.visible').click();
        cy.wait(3000); // Optional: Add a wait if needed for page load
    }

    verifyCartPageLoaded() {
        cy.contains('Place Order').should('be.visible');
    }

    verifyTotalPrice(expectedTotalPrice) {
        cy.get('#totalp')
            .should('be.visible')
            .invoke('text')
            .then((text) => {
                const actualPrice = parseInt(text.trim(), 10);
                expect(expectedTotalPrice).to.equal(actualPrice);
            });
    }

    verifyNumberOfItems(expectedCount) {
        cy.get('#tbodyid tr')
            .its('length')
            .then((rowCount) => {
                expect(rowCount).to.equal(expectedCount);
            });
    }

    clearCart(numberOfItems) {
        for (let i = 0; i < numberOfItems; i++) {
            cy.contains('a', 'Delete')
                .should('be.visible')
                .click();
            cy.wait(1000); // Optional: Add wait if needed
        }
    }
}

export default new CartPage();
