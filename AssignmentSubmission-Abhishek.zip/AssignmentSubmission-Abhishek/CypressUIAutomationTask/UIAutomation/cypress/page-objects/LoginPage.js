class LoginPage {
  openLoginModal() {
      cy.get('[data-target="#logInModal"]').click();
  }

  enterUsername(username) {
      cy.get('#loginusername').should('be.visible').clear().type(username, { delay: 100 });
  }

  enterPassword(password) {
      cy.get('#loginpassword').clear().type(password, { delay: 100 });
  }

  clickLoginButton() {
      cy.get('[class="btn btn-primary"]').eq(2).click();
  }

  verifyAlertText(expectedText) {
      cy.on('window:alert', (alertText) => {
          expect(alertText).to.contains(expectedText);
      });
  }

  verifyUserLoggedIn(username) {
      cy.contains(`Welcome ${username}`).should('be.visible');
  }

logout() {
    cy.get('#logout2').should('be.visible').click();
    // Simulate browser closure by clearing session state
    cy.clearCookies();
    cy.clearLocalStorage();    
}


}

export default new LoginPage();
