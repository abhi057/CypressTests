class ProductsPage {

    fetchProductPrice(productName){
        cy.wait(3000)
        cy.contains('a', productName)
            .parent()
            .siblings()
            .first()
            .invoke('text')
            .then((priceText) => {
                const amount = parseFloat(priceText.replace('$', ''));
                return amount
            });  
    }

    selectProduct(productName) {
        cy.contains('a', productName).should('be.visible').click();
    }

    addToCart(times) {
        for (let i = 0; i < times; i++) {
            cy.wait(1000)
            cy.contains('a', 'Add to cart')
                .should('be.visible')
                .click();
            cy.on('window:alert', (alertText) => {
                expect(alertText).to.contains('Product added.');             
            });
        }
    }
}

export default new ProductsPage();
