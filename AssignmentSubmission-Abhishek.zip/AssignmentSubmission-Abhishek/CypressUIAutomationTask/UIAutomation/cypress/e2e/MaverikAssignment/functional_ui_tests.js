/// <reference types="cypress" />
import LoginPage from '../../page-objects/LoginPage';
import ProductPage from '../../page-objects/ProductsPage';
import CartPage from '../../page-objects/CartPage';

describe('Functional UI Test Suite', () => {
    const validUsername = 'Abhitest2009';
    const validPassword = 'qwerty123';
    const invalidUsername = 'InvalidUser';
    const invalidPassword = 'InvalidPassword';
    const productName = 'Samsung galaxy s6';
    const numberOfItemsToAdd = 3;
    const price = 360;

    //hook to lauch application 
    beforeEach('Open application', () => {
        cy.visit('/')
    })
    
    //Test 1
    it('Verify login is not successful with invalid username', () => {
        LoginPage.openLoginModal();
        LoginPage.enterUsername(invalidUsername);
        LoginPage.enterPassword(validPassword);
        LoginPage.clickLoginButton();
        LoginPage.verifyAlertText('User does not exist.');
    });

    //Test 2
    it('Verify login is not successful with invalid password', () => {
        LoginPage.openLoginModal();
        LoginPage.enterUsername(validUsername);
        LoginPage.enterPassword(invalidPassword);
        LoginPage.clickLoginButton();
        LoginPage.verifyAlertText('Wrong password.');
    });

    //Test 3
    it('Verify login is successful with valid credentials', () => {
        LoginPage.openLoginModal();
        LoginPage.enterUsername(validUsername);
        LoginPage.enterPassword(validPassword);
        LoginPage.clickLoginButton();
        LoginPage.verifyUserLoggedIn(validUsername);
    });

    //Test 4
    it('Verify Add to Cart functionality', () => {
        LoginPage.openLoginModal();
        LoginPage.enterUsername(validUsername);
        LoginPage.enterPassword(validPassword);
        LoginPage.clickLoginButton();
        LoginPage.verifyUserLoggedIn(validUsername);

       // let price, totalPrice;
       //  price = ProductPage.fetchProductPrice(productName)

        let  totalPrice;
        totalPrice = price * numberOfItemsToAdd;

        ProductPage.selectProduct(productName);
        ProductPage.addToCart(numberOfItemsToAdd);

        CartPage.openCart();
        CartPage.verifyCartPageLoaded();
        CartPage.verifyTotalPrice(totalPrice);
        CartPage.verifyNumberOfItems(numberOfItemsToAdd);

        CartPage.clearCart(numberOfItemsToAdd);

        //Logout user
        LoginPage.logout();

    });
});
