# CypressUIAutomation

## Tech Stack
This project utilizes **Cypress** and **JavaScript** with the **Page Object Design Pattern** for structuring test scripts. For reporting, it integrates **mochawesome** to generate HTML reports.


Directory Structure

cypress-git-repo
├── ngx-cypress-test
│   ├── cypress
│   │   ├── e2e
│   │   │   ├── MaverickAssignment --functional_ui_tests.js
│   │   ├── page-objects
│   │   │   ├── LoginPage.js
│   │   │   ├── ProductPage.js
│   │   │   ├── CartPage.js
│   │   └── reports (generated after test execution)
│   ├── package.json
│   ├── README.md


Note:
Ensure all dependencies are installed before running the tests:

---

## How to Run
1. Navigate to the project directory:
   
   cd cypress-git-repo/ngx-cypress-test
Execute the test suite using the following command:


npm run test

The main script for this framework is:functional_ui_tests.js

-----
The following test scenarios are implemented using the Page Object Design Pattern:

Test Case 1 (Negative):
Scenario: Verify that the user cannot log in to demoblaze.com with an invalid username.
Validation: Assert the error message displayed.
Test Case 2 (Negative):
Scenario: Verify that the user cannot log in to demoblaze.com with an invalid password.
Validation: Assert the error message displayed.
Test Case 3 (Positive):
Scenario: Verify that the user can successfully log in with valid credentials.
Validation: Assert that the login is successful.
Test Case 4 (Positive): Add to Cart Feature
Steps:
Select a particular product.
Add the product to the cart multiple times.
Validate:
The product is added to the cart the specified number of times.
The total price displayed in the cart matches the expected value.
---
Screenshots
For detailed screenshots of the test results and UI interactions, please refer to the attached Word document.

---
Reporting
Test results are automatically generated in HTML format using mochawesome for easy visualization

----
The test scripts rely on the structure provided in the Page Object Model for better maintainability and scalability.

